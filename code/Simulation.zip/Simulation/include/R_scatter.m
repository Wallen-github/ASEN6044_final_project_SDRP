function Z = R_scatter(x, offsets)
    

    
end

