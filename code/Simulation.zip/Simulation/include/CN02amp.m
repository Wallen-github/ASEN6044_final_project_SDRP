function amp = CN02amp(CN0)
    amp = sqrt(db2pow(CN0) / 2);
end

