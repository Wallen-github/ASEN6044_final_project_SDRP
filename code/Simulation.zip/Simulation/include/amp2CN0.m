function CN0 = amp2CN0(amp)
    CN0 = pow2db(amp.^2 * 2);
end

